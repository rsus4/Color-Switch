package sample;

import javafx.application.Application;
import javafx.scene.shape.Arc;
import javafx.stage.Stage;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import javafx.animation.*;

public class Circle extends Application {
    private final Arc a1,a2,a3,a4;
    private final AnchorPane root;

    public Circle(AnchorPane root, Stage stage) throws Exception {
        a1=new Arc();
        a1.setCenterX(215);
        a1.setCenterY(200);
        a1.setRadiusX(100);
        a1.setRadiusY(100);
        a1.setStartAngle(90.0f);
        a1.setLength(90.0f);
        a1.setStrokeWidth(20);
        a1.setFill(Color.TRANSPARENT);
        a1.setStroke(Color.AQUA);

        a2=new Arc();
        a2.setCenterX(215);
        a2.setCenterY(200);
        a2.setRadiusX(100);
        a2.setRadiusY(100);
        a2.setStartAngle(0.0f);
        a2.setLength(90.0f);
        a2.setStrokeWidth(20);
        a2.setFill(Color.TRANSPARENT);
        a2.setStroke(Color.BLUEVIOLET);

        a3=new Arc();
        a3.setCenterX(215);
        a3.setCenterY(200);
        a3.setRadiusX(100);
        a3.setRadiusY(100);
        a3.setStartAngle(270.0f);
        a3.setLength(90.0f);
        a3.setStrokeWidth(20);
        a3.setFill(Color.TRANSPARENT);
        a3.setStroke(Color.DEEPPINK);

        a4=new Arc();
        a4.setCenterX(215);
        a4.setCenterY(200);
        a4.setRadiusX(100);
        a4.setRadiusY(100);
        a4.setStartAngle(180.0f);
        a4.setLength(90.0f);
        a4.setStrokeWidth(20);
        a4.setFill(Color.TRANSPARENT);
        a4.setStroke(Color.YELLOW);
        this.root=root;
        this.start(stage);
    }

    @Override
    public void start(Stage stage) throws Exception {
        root.getChildren().addAll(a1,a2,a3,a4);

        Timeline animation1 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(a1.startAngleProperty(), a1.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(a1.startAngleProperty(), a1.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation1.setCycleCount(Animation.INDEFINITE);

        Timeline animation2 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(a2.startAngleProperty(), a2.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(a2.startAngleProperty(), a2.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation2.setCycleCount(Animation.INDEFINITE);

        Timeline animation3 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(a3.startAngleProperty(), a3.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(a3.startAngleProperty(), a3.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation3.setCycleCount(Animation.INDEFINITE);

        Timeline animation4 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(a4.startAngleProperty(), a4.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(a4.startAngleProperty(), a4.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation4.setCycleCount(Animation.INDEFINITE);

        animation1.play();
        animation2.play();
        animation3.play();
        animation4.play();
    }
}
