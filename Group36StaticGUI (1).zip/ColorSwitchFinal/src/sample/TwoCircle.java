package sample;

import javafx.application.Application;
import javafx.scene.shape.Arc;
import javafx.stage.Stage;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import javafx.animation.*;

public class TwoCircle extends Application {
    private final Arc b1, b2, b3, b4, b5, b6, b7, b8;
    private final AnchorPane root;

    public TwoCircle(AnchorPane root, Stage stage) throws Exception {
        b1=new Arc();
        b1.setCenterX(160);
        b1.setCenterY(200);
        b1.setRadiusX(50);
        b1.setRadiusY(50);
        b1.setStartAngle(90.0f);
        b1.setLength(90.0f);
        b1.setStrokeWidth(10);
        b1.setFill(Color.TRANSPARENT);
        b1.setStroke(Color.AQUA);

        b2=new Arc();
        b2.setCenterX(160);
        b2.setCenterY(200);
        b2.setRadiusX(50);
        b2.setRadiusY(50);
        b2.setStartAngle(0.0f);
        b2.setLength(90.0f);
        b2.setStrokeWidth(10);
        b2.setFill(Color.TRANSPARENT);
        b2.setStroke(Color.BLUEVIOLET);

        b3=new Arc();
        b3.setCenterX(160);
        b3.setCenterY(200);
        b3.setRadiusX(50);
        b3.setRadiusY(50);
        b3.setStartAngle(270.0f);
        b3.setLength(90.0f);
        b3.setStrokeWidth(10);
        b3.setFill(Color.TRANSPARENT);
        b3.setStroke(Color.DEEPPINK);

        b4=new Arc();
        b4.setCenterX(160);
        b4.setCenterY(200);
        b4.setRadiusX(50);
        b4.setRadiusY(50);
        b4.setStartAngle(180.0f);
        b4.setLength(90.0f);
        b4.setStrokeWidth(10);
        b4.setFill(Color.TRANSPARENT);
        b4.setStroke(Color.YELLOW);

        b5=new Arc();
        b5.setCenterX(270);
        b5.setCenterY(200);
        b5.setRadiusX(50);
        b5.setRadiusY(50);
        b5.setStartAngle(180.0f);
        b5.setLength(90.0f);
        b5.setStrokeWidth(10);
        b5.setFill(Color.TRANSPARENT);
        b5.setStroke(Color.DEEPPINK);

        b6=new Arc();
        b6.setCenterX(270);
        b6.setCenterY(200);
        b6.setRadiusX(50);
        b6.setRadiusY(50);
        b6.setStartAngle(90.0f);
        b6.setLength(90.0f);
        b6.setStrokeWidth(10);
        b6.setFill(Color.TRANSPARENT);
        b6.setStroke(Color.BLUEVIOLET);

        b7=new Arc();
        b7.setCenterX(270);
        b7.setCenterY(200);
        b7.setRadiusX(50);
        b7.setRadiusY(50);
        b7.setStartAngle(0.0f);
        b7.setLength(90.0f);
        b7.setStrokeWidth(10);
        b7.setFill(Color.TRANSPARENT);
        b7.setStroke(Color.AQUA);

        b8=new Arc();
        b8.setCenterX(270);
        b8.setCenterY(200);
        b8.setRadiusX(50);
        b8.setRadiusY(50);
        b8.setStartAngle(270.0f);
        b8.setLength(90.0f);
        b8.setStrokeWidth(10);
        b8.setFill(Color.TRANSPARENT);
        b8.setStroke(Color.YELLOW);
        this.root=root;
        this.start(stage);
    }

    @Override
    public void start(Stage stage) throws Exception {
        root.getChildren().addAll(b1, b2, b3, b4, b5, b6, b7, b8);

        Timeline animation1 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(b1.startAngleProperty(), b1.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(b1.startAngleProperty(), b1.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation1.setCycleCount(Animation.INDEFINITE);

        Timeline animation2 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(b2.startAngleProperty(), b2.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(b2.startAngleProperty(), b2.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation2.setCycleCount(Animation.INDEFINITE);

        Timeline animation3 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(b3.startAngleProperty(), b3.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(b3.startAngleProperty(), b3.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation3.setCycleCount(Animation.INDEFINITE);

        Timeline animation4 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(b4.startAngleProperty(), b4.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(b4.startAngleProperty(), b4.getStartAngle() - 360, Interpolator.LINEAR))

        );
        animation4.setCycleCount(Animation.INDEFINITE);

        Timeline animation5 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(b5.startAngleProperty(), b5.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(b5.startAngleProperty(), b5.getStartAngle() + 360, Interpolator.LINEAR))

        );
        animation5.setCycleCount(Animation.INDEFINITE);

        Timeline animation6 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(b6.startAngleProperty(), b6.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(b6.startAngleProperty(), b6.getStartAngle() + 360, Interpolator.LINEAR))

        );
        animation6.setCycleCount(Animation.INDEFINITE);

        Timeline animation7 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(b7.startAngleProperty(), b7.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(b7.startAngleProperty(), b7.getStartAngle() + 360, Interpolator.LINEAR))

        );
        animation7.setCycleCount(Animation.INDEFINITE);

        Timeline animation8 = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(b8.startAngleProperty(), b8.getStartAngle(), Interpolator.LINEAR)),
                new KeyFrame(Duration.seconds(2), new KeyValue(b8.startAngleProperty(), b8.getStartAngle() + 360, Interpolator.LINEAR))

        );
        animation8.setCycleCount(Animation.INDEFINITE);

        animation1.play();
        animation2.play();
        animation3.play();
        animation4.play();
        animation5.play();
        animation6.play();
        animation7.play();
        animation8.play();
    }
}
