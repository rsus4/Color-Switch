package sample;

public class IntroScreen {
}
