package sample;

import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Plus extends Application {
    private final Line l1, l2, l3, l4;
    private final AnchorPane root;

    public Plus(AnchorPane root, Stage stage) throws Exception {

        l1=new Line();
        l1.setEndX(100);
        l1.setLayoutX(90);
        l1.setLayoutY(192);
        l1.setStartX(12);
        l1.setStroke(Color.YELLOW);
        l1.setStrokeLineCap(StrokeLineCap.ROUND);
        l1.setStrokeWidth(25);

        l2=new Line();
        l2.setEndX(100);
        l2.setLayoutX(146);
        l2.setLayoutY(139);
        l2.setRotate(90.0f);
        l2.setStartX(12);
        l2.setStroke(Color.AQUA);
        l2.setStrokeLineCap(StrokeLineCap.ROUND);
        l2.setStrokeWidth(25);

        l3=new Line();
        l3.setEndX(100);
        l3.setLayoutX(203);
        l3.setLayoutY(192);
        l3.setStartX(12);
        l3.setStroke(Color.DEEPPINK);
        l3.setStrokeLineCap(StrokeLineCap.ROUND);
        l3.setStrokeWidth(25);

        l4=new Line();
        l4.setEndX(100);
        l4.setLayoutX(146);
        l4.setLayoutY(246);
        l4.setStartX(12);
        l4.setRotate(90);
        l4.setStroke(Color.BLUEVIOLET);
        l4.setStrokeLineCap(StrokeLineCap.ROUND);
        l4.setStrokeWidth(25);
        this.root=root;
        this.start(stage);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Group g=new Group();
        g.getChildren().addAll(l2,l4, l1, l3);
        root.getChildren().add(g);

        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(-3600);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setDuration(Duration.millis(25000));
        rotate.setNode(g);
        rotate.play();
    }

}
