package sample;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.Stage;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import javafx.scene.transform.Rotate;
import javafx.animation.*;

public class Rhombus extends Application {
    private final Line l1, l2, l3, l4;
    private final AnchorPane root;
    
    public Rhombus(AnchorPane root, Stage stage) throws Exception {
        l1=new Line();
        l1.setEndY(47.0);
        l1.setLayoutX(200);
        l1.setLayoutY(209);
        l1.setStartX(-49);
        l1.setStartY(-17);
        l1.setStroke(Color.YELLOW);
        l1.setStrokeLineCap(StrokeLineCap.ROUND);
        l1.setStrokeWidth(15);

        l2=new Line();
        l2.setEndY(69);
        l2.setLayoutX(200);
        l2.setLayoutY(187);
        l2.setStartX(44);
        l2.setStartY(3.5);
        l2.setStroke(Color.AQUA);
        l2.setStrokeLineCap(StrokeLineCap.ROUND);
        l2.setStrokeWidth(15);

        l3=new Line();
        l3.setEndX(43);
        l3.setEndY(68);
        l3.setLayoutX(201);
        l3.setLayoutY(121);
        l3.setStroke(Color.DEEPPINK);
        l3.setStrokeLineCap(StrokeLineCap.ROUND);
        l3.setStrokeWidth(15);

        l4=new Line();
        l4.setEndX(-49);
        l4.setEndY(70);
        l4.setLayoutX(200);
        l4.setLayoutY(121);
        l4.setStroke(Color.BLUEVIOLET);
        l4.setStrokeLineCap(StrokeLineCap.ROUND);
        l4.setStrokeWidth(15);
        this.root=root;
        this.start(stage);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Group g=new Group();
        g.getChildren().addAll(l1,l2,l3,l4);
        root.getChildren().add(g);

        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(3600);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setDuration(Duration.millis(25000));
        rotate.setNode(g);
        rotate.play();
    } 
    
    
}
