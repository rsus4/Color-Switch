package sample;

import javafx.animation.Animation;
import javafx.animation.PathTransition;
import javafx.animation.PathTransition.OrientationType;
import javafx.animation.RotateTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcTo;
import javafx.scene.shape.ClosePath;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.Circle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

public class DottedCircle extends Application {
    private PathTransition pt1;
    private final Circle c1,c2,c3,c4,c5,c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21,c22,c23,c24;
    private RotateTransition rotate;
    private final AnchorPane root;

    public DottedCircle(AnchorPane root, Stage stage) throws Exception {
        c1=new Circle(189,101,10);
        c1.setFill(Color.DEEPPINK);
        c2=new Circle(107,180,10);
        c2.setFill(Color.DEEPPINK);
        c3=new Circle(166,107,10);
        c3.setFill(Color.DEEPPINK);
        c4=new Circle(147,119,10);
        c4.setFill(Color.DEEPPINK);
        c5=new Circle(116,156,10);
        c5.setFill(Color.DEEPPINK);
        c6=new Circle(131,135,10);
        c6.setFill(Color.DEEPPINK);
        c7=new Circle(216,100,10);
        c7.setFill(Color.YELLOW);
        c8=new Circle(243,108,10);
        c8.setFill(Color.YELLOW);
        c9=new Circle(265,119,10);
        c9.setFill(Color.YELLOW);
        c10=new Circle(302,179,10);
        c10.setFill(Color.YELLOW);
        c11=new Circle(294,155,10);
        c11.setFill(Color.YELLOW);
        c12=new Circle(281,135,10);
        c12.setFill(Color.YELLOW);
        c13=new Circle(106,209,10);
        c13.setFill(Color.AQUA);
        c14=new Circle(112,236,10);
        c14.setFill(Color.AQUA);
        c15=new Circle(124,259,10);
        c15.setFill(Color.AQUA);
        c16=new Circle(142,278,10);
        c16.setFill(Color.AQUA);
        c17=new Circle(164,291,10);
        c17.setFill(Color.AQUA);
        c18=new Circle(189,301,10);
        c18.setFill(Color.AQUA);
        c19=new Circle(304,209,10);
        c19.setFill(Color.BLUEVIOLET);
        c20=new Circle(298,236,10);
        c20.setFill(Color.BLUEVIOLET);
        c21=new Circle(286,259,10);
        c21.setFill(Color.BLUEVIOLET);
        c22=new Circle(269,278,10);
        c22.setFill(Color.BLUEVIOLET);
        c23=new Circle(244,291,10);
        c23.setFill(Color.BLUEVIOLET);
        c24=new Circle(216,301,10);
        c24.setFill(Color.BLUEVIOLET);

        this.root=root;
        this.start(stage);
    }

    private void init(Stage primaryStage) {
        Group g1=new Group();
        g1.getChildren().addAll(c1, c2, c3, c4, c5, c6,c7,c8,c9,c10,c11,c12,c13,c14,c15,c16,c17,c18,c19,c20,c21,c22,c23,c24);
        root.getChildren().add(g1);

        rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(-3600);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setDuration(Duration.millis(25000));
        rotate.setNode(g1);
        rotate.play();

        Path path2 = createEllipsePath(300, 200, 100, 100, 0);

        pt1 = new PathTransition();
        pt1.setDuration(Duration.seconds(2));
        pt1.setPath(path2);
        pt1.setNode(c1);
        pt1.setOrientation(OrientationType.ORTHOGONAL_TO_TANGENT);
        pt1.setCycleCount(Timeline.INDEFINITE);

    }

    private Path createEllipsePath(double centerX, double centerY, double radiusX, double radiusY, double rotate) {
        ArcTo arcTo = new ArcTo();
        arcTo.setX(centerX - radiusX + 1);
        arcTo.setY(centerY - radiusY);
        arcTo.setSweepFlag(false);
        arcTo.setLargeArcFlag(true);
        arcTo.setRadiusX(radiusX);
        arcTo.setRadiusY(radiusY);
        arcTo.setXAxisRotation(rotate);

        Path path = new Path();
        path.getElements().addAll(
                new MoveTo(centerX-radiusX, centerY-radiusY),
                arcTo,
                new ClosePath());
        return path;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        init(primaryStage);
        primaryStage.show();
    }
}