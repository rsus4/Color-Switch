package sample;

import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Triangle extends Application {
    private final Rectangle r1, r2, r3;
    private final Polygon t1,t2,t3,t4,t5,t6;
    private final AnchorPane root;

    public Triangle(AnchorPane root, Stage stage) throws Exception{
        r1=new Rectangle();
        r1.setHeight(150);
        r1.setLayoutX(147);
        r1.setLayoutY(115);
        r1.setRotate(30);
        r1.setWidth(25);
        r1.setFill(Color.AQUA);

        r2=new Rectangle();
        r2.setHeight(150);
        r2.setLayoutX(242);
        r2.setLayoutY(115);
        r2.setRotate(-30);
        r2.setWidth(25);
        r2.setFill(Color.DEEPPINK);

        r3=new Rectangle();
        r3.setHeight(150);
        r3.setLayoutX(194);
        r3.setLayoutY(197);
        r3.setRotate(90);
        r3.setWidth(25);
        r3.setFill(Color.YELLOW);

        t1=new Polygon();
        t1.getPoints().addAll(-42.79129409790039, 41.90371322631836, -17.97125816345215, 40.74338150024414, -39.923545837402344, 2.566340208053589);
        t1.setFill(Color.AQUA);
        t1.setLayoutX(236);
        t1.setLayoutY(87);
        t1.setRotate(30);

        t2=new Polygon();
        t2.getPoints().addAll(-42.791290283203125, 43.75, -18.25, 37.75, -42.791290283203125, -0.5);
        t2.setFill(Color.DEEPPINK);
        t2.setLayoutX(250);
        t2.setLayoutY(88);

        t3=new Polygon();
        t3.getPoints().addAll(-59.75, 43.5, -18.5, 43.5, -17.97125244140625, 19.5);
        t3.setFill(Color.YELLOW);
        t3.setLayoutX(150);
        t3.setLayoutY(241);

        t4=new Polygon();
        t4.getPoints().addAll(25.0, 43.5, -18.5, 43.5, -18.5, 18.5);
        t4.setFill(Color.YELLOW);
        t4.setLayoutX(299);
        t4.setLayoutY(241);

        t5=new Polygon();
        t5.getPoints().addAll(-54.75, 42.5, -12.97125244140625, 18.5, -31.75, 3.5);
        t5.setFill(Color.AQUA);
        t5.setLayoutX(145);
        t5.setLayoutY(242);

        t6=new Polygon();
        t6.getPoints().addAll(-65.75, 25.25, -24.0, 49.5, -49.0, 7.25);
        t6.setFill(Color.DEEPPINK);
        t6.setLayoutX(348);
        t6.setLayoutY(235);

        this.root=root;
        this.start(stage);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Group g=new Group();
        g.getChildren().addAll(r1,r2,r3,t1,t2,t3,t4,t5,t6);
        root.getChildren().add(g);

        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(-3600);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setDuration(Duration.millis(25000));
        rotate.setNode(g);
        rotate.play();
    }


}
